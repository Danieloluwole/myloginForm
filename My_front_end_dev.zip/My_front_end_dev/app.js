let username = document.getElementById('Username');

const password= document.getElementById('password');

const password2= document.getElementById('password2');

const email= document.getElementById('email');

const form = document.getElementById('form');

form.addEventListener('submit',(e)=>{
  
 e.preventDefault();
  
 
  validateInput();
});

function validateInput(){

//get user inputs
let name = username.value.trim();

let pass = password.value.trim();

let pass2 = password2.value.trim();

let mail = email.value.trim();


 if(name=="") {
 
 Error(username,"Username cannot be blank");

   }
   
else if(!name==''){
   Success(username);
}

if(name.length > 20){
   
      Error(username,"Username should not exceed 20 characters.");
   
   }
if (name.length <= 5 && name
   .length!=0) {

Error(username,"Name too short ");
   }
   
 if (pass=="")
 {
 Error(password,"Enter a valid password ")
    
 }

else if(!pass=="") {
   Success(password)
}
if(mail=="") {

Error(email,"Email cannot be blank.")
   
}

if (!mail=="") {

Success(email)
   
}

if(pass2=="") {
   Error(password2,"Enter a valid password ")

}

if (!pass2=='') {

Error(password2);
   
}

if (pass!=pass2) {

Error(password2,"Passwords do not match");
   
}

else if(pass2==pass && pass2.length!=0){
   Success(password2);
}
}


//Error function 
function Error(input,message){


   let formControl =            input.parentElement;

   formControl.className= "form-control error";

   let small=formControl.querySelector('small');

   small.innerText=message;
}

//SUCCESS function 

function Success(input){

   
   let formControl = input.parentElement;

formControl.className= "form-control success";

}
